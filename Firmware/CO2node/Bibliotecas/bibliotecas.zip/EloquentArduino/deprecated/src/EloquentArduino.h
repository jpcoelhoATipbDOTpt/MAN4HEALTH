#pragma once


#define _ELOQUENTARDUINO_H_ 1