#ifndef ELOQUENTARDUINO_ELOQUENT_H
#define ELOQUENTARDUINO_ELOQUENT_H


// entry point for the Eloquent Arduino library
#include "./eloquent/utils.h"

#endif //ELOQUENTARDUINO_ELOQUENT_H
