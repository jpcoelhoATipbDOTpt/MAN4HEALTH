//
// Created by Simone on 24/03/2022.
//

#include "./jpeg/JpegEncoder.h"