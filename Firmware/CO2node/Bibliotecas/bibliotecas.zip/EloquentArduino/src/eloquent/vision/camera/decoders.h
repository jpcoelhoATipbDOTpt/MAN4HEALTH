//
// Created by Simone on 06/07/2022.
//

#pragma once

#include "./decoders/gray.h"