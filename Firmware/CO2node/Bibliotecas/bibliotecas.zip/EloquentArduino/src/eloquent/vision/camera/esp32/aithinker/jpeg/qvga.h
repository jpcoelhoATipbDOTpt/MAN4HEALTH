//
// Created by Simone on 24/06/2022.
//

#pragma once


#include "../jpeg.h"

ELOQUENT_SINGLETON(Eloquent::Vision::Cam::Esp32::QvgaJpegCamera camera);